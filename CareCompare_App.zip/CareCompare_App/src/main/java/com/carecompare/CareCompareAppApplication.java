package com.carecompare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareCompareAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CareCompareAppApplication.class, args);
	}

}
